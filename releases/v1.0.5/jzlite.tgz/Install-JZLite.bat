@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title JZLite Setup

set "INTERACTIVE=0"
set "MODE=%~1"
set "PAYLOAD_DIR=%~dp0"

if exist "%PAYLOAD_DIR%JZLite-Setup.exe" goto payload_ready
if exist "%PAYLOAD_DIR%..\dist\JZLite-Setup.exe" set "PAYLOAD_DIR=%PAYLOAD_DIR%..\dist\"

:payload_ready
cd /d "%PAYLOAD_DIR%"
if not defined MODE (
  set "INTERACTIVE=1"
  goto interactive_menu
)
goto check_mode

:interactive_menu
cls
echo ============================================================
echo                    JZLite Modem Setup
echo ============================================================
echo.
echo   [1] Temporary clean install
echo       Runs from /tmp and is removed when the modem reboots.
echo.
echo   [2] Migrate from XLite
echo       Backs up XLite, imports supported profiles, and installs JZLite.
echo.
echo   [3] Install JZLite (Keep XLite / Coexist)
echo       Installs under /mnt/userdata/jzlite alongside XLite without replacing it.
echo.
echo   [4] Install persistently (Clean)
echo       Installs under /mnt/userdata/jzlite with boot autostart.
echo.
echo   [5] Upgrade persistent installation
echo       Replaces binaries while retaining profiles and settings.
echo.
echo   [6] Uninstall JZLite (Restore XLite)
echo       Removes JZLite, restores an XLite backup when present,
echo       and restores networking rules.
echo.
echo   [7] Complete Wipe (Remove JZLite and XLite)
echo       Completely uninstalls JZLite and deletes XLite,
echo       restoring clean stock modem networking.
echo.
echo   [8] Exit
echo.
set "CHOICE="
set /p "CHOICE=Choose [1-8]: "
if "%CHOICE%"=="1" set "MODE=--clean-install" & goto mode_ok
if "%CHOICE%"=="2" set "MODE=--migrate-xlite" & goto mode_ok
if "%CHOICE%"=="3" set "MODE=--install-coexist" & goto mode_ok
if "%CHOICE%"=="4" set "MODE=--install-persistent" & goto mode_ok
if "%CHOICE%"=="5" set "MODE=--upgrade-persistent" & goto mode_ok
if "%CHOICE%"=="6" set "MODE=--uninstall" & goto mode_ok
if "%CHOICE%"=="7" set "MODE=--uninstall-all" & goto mode_ok
if "%CHOICE%"=="8" exit /b 0
echo.
echo ERROR: Enter a number from 1 to 8.
timeout /t 2 >nul
goto interactive_menu

:check_mode
if /i "%MODE%"=="--version" goto show_version
if /i "%MODE%"=="--clean-install" goto mode_ok
if /i "%MODE%"=="--install-persistent" goto mode_ok
if /i "%MODE%"=="--install-coexist" goto mode_ok
if /i "%MODE%"=="--coexist-xlite" set "MODE=--install-coexist" & goto mode_ok
if /i "%MODE%"=="--migrate-xlite" goto mode_ok
if /i "%MODE%"=="--upgrade-persistent" goto mode_ok
if /i "%MODE%"=="--uninstall" goto mode_ok
if /i "%MODE%"=="--uninstall-all" goto mode_ok
goto usage

:show_version
if not "%~2"=="" goto usage
if not exist "JZLite-Setup.exe" (
  echo ERROR: JZLite-Setup.exe is missing. Run scripts\build.ps1 first.
  exit /b 1
)
JZLite-Setup.exe --version
exit /b %ERRORLEVEL%

:mode_ok
if not "%~2"=="" (
  echo ERROR: Choose exactly one setup option.
  goto usage
)
if not exist "adb.exe" (
  echo ERROR: adb.exe is missing from the JZLite folder.
  goto failed
)
if not exist "JZLite-Setup.exe" (
  echo ERROR: JZLite-Setup.exe is missing. Run scripts\build.ps1 first.
  goto failed
)

echo Checking the connected modem...
set "DEVICE_COUNT=0"
for /f "skip=1 tokens=1,2" %%A in ('adb.exe devices 2^>nul') do if "%%B"=="device" call set /a DEVICE_COUNT+=1
if not "%DEVICE_COUNT%"=="1" (
  echo ERROR: Connect exactly one authorized USB ADB modem.
  echo Check the USB cable, enable ADB, and accept any authorization prompt.
  goto failed
)

set "ROOT_ID="
for /f "usebackq delims=" %%I in (`adb.exe shell "id" 2^>nul`) do if not defined ROOT_ID set "ROOT_ID=%%I"
echo %ROOT_ID% | findstr /c:"uid=0" >nul
if errorlevel 1 (
  setlocal EnableDelayedExpansion
  echo ADB shell is not root. Requesting an ADB root restart...
  set "ROOT_RESULT="
  for /f "usebackq delims=" %%I in (`adb.exe root 2^>^&1`) do if not defined ROOT_RESULT set "ROOT_RESULT=%%I"
  timeout /t 3 /nobreak >nul
  set "ROOT_ID="
  for /f "usebackq delims=" %%I in (`adb.exe shell "id" 2^>nul`) do if not defined ROOT_ID set "ROOT_ID=%%I"
  echo !ROOT_ID! | findstr /c:"uid=0" >nul
  if errorlevel 1 (
    echo ERROR: This modem firmware did not provide a root ADB shell.
    if defined ROOT_RESULT echo ADB response: !ROOT_RESULT!
    echo Shell identity: !ROOT_ID!
    echo JZLite cannot safely install or change routing without modem root access.
    echo Confirm this modem uses the same root-enabled firmware as the supported test modem.
    goto failed
  )
  echo Root ADB shell is ready.
  endlocal
)

if /i "%MODE%"=="--uninstall" goto launch_setup
if /i "%MODE%"=="--uninstall-all" goto launch_setup
set "MEM_TOTAL_KB="
for /f "tokens=2" %%M in ('adb.exe shell "cat /proc/meminfo" 2^>nul ^| findstr /b /c:"MemTotal:"') do set "MEM_TOTAL_KB=%%M"
if defined MEM_TOTAL_KB (
  if %MEM_TOTAL_KB% LEQ 290000 (
    set /a "MEM_TOTAL_MIB=MEM_TOTAL_KB/1024"
    echo.
    echo ============================================================
    echo [WARNING] MODEM HAS ONLY %MEM_TOTAL_KB% KB RAM TOTAL!
    echo NOT RECOMMENDED TO INSTALL DUE TO SMALL MEMORY SIZE.
    echo PROCEED WITH YOUR OWN RISK!
    echo ============================================================
    echo.
    timeout /t 3 >nul
  )
)

set "MEM_AVAILABLE_KB="
for /f "tokens=2" %%M in ('adb.exe shell "cat /proc/meminfo" 2^>nul ^| findstr /b /c:"MemAvailable:"') do set "MEM_AVAILABLE_KB=%%M"
if not defined MEM_AVAILABLE_KB (
  echo ERROR: Could not read available modem memory.
  goto failed
)
set /a "MEM_AVAILABLE_MIB=MEM_AVAILABLE_KB/1024"
echo Available modem memory: %MEM_AVAILABLE_MIB% MiB
if %MEM_AVAILABLE_KB% LSS 20480 (
  echo ERROR: JZLite requires at least 20 MiB of available modem memory.
  echo Reboot the modem and try again.
  goto failed
)

:launch_setup
echo.
echo Launching JZLite Setup %MODE%...
JZLite-Setup.exe %MODE%
set "JZLITE_EXIT=%ERRORLEVEL%"
if not "%JZLITE_EXIT%"=="0" (
  echo.
  echo ERROR: Setup failed with exit code %JZLITE_EXIT%.
  if "%INTERACTIVE%"=="1" pause
  exit /b %JZLITE_EXIT%
)

if /i "%MODE%"=="--uninstall" (
  echo.
  echo JZLite was uninstalled successfully.
  if "%INTERACTIVE%"=="1" pause
  exit /b 0
)

set "MODEM_IP="
for /f "usebackq tokens=*" %%I in (`adb.exe shell "/mnt/userdata/jzlite/bin/jzlite-probe -lan-ip 2>/dev/null || /tmp/jzlite-test/jzlite-probe -lan-ip 2>/dev/null || uci get network.lan.ipaddr 2>/dev/null" 2^>nul`) do if not defined MODEM_IP set "MODEM_IP=%%I"
if not defined MODEM_IP for /f "tokens=2" %%I in ('adb.exe shell "ip -4 addr show br0 2^>/dev/null || ip -4 addr show br-lan 2^>/dev/null" 2^>nul ^| findstr /c:"inet "') do if not defined MODEM_IP set "MODEM_IP=%%I"
for /f "tokens=1 delims=/" %%I in ("%MODEM_IP%") do set "MODEM_IP=%%I"
if not defined MODEM_IP set "MODEM_IP=192.168.0.1"

echo.
echo ============================================================
echo JZLite Installed and Running Successfully!
echo Please access the Web Dashboard at:
echo https://%MODEM_IP%:5443
echo.
echo The modem uses a local certificate. Accept the browser
echo warning only when the address above matches your modem.
echo ============================================================
if "%INTERACTIVE%"=="1" pause
exit /b 0

:usage
echo Usage: Install-JZLite.bat [option]
echo.
echo   --version
echo   --clean-install
echo   --migrate-xlite
echo   --install-persistent
echo   --upgrade-persistent
echo   --uninstall
exit /b 2

:failed
if "%INTERACTIVE%"=="1" pause
exit /b 1
