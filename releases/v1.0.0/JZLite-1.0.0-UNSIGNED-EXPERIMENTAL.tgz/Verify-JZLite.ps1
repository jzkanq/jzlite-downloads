param(
    [Parameter(Mandatory = $true)]
    [string]$ExtractedFolder,
    [Alias('AllowUnsignedPrivateTest')]
    [switch]$AllowUnsignedExperimental
)

$ErrorActionPreference = 'Stop'
$folder = (Resolve-Path -LiteralPath $ExtractedFolder).Path
$manifest = Join-Path $folder 'SHA256SUMS.txt'
$installer = Join-Path $folder 'JZLite-Setup.exe'
if (-not (Test-Path -LiteralPath $manifest) -or -not (Test-Path -LiteralPath $installer)) {
    throw 'The extracted release is missing its installer or checksum manifest.'
}

$signature = Get-AuthenticodeSignature -LiteralPath $installer
if ($signature.Status -eq 'NotSigned' -and $AllowUnsignedExperimental) {
    Write-Warning 'Installer is unsigned. Continue only if the archive SHA-256 was received through a separate trusted channel.'
} elseif ($signature.Status -ne 'Valid') {
    throw "Installer signature is not trusted: $($signature.Status)"
}
foreach ($line in Get-Content -LiteralPath $manifest) {
    if ($line -notmatch '^([0-9a-f]{64})  ([A-Za-z0-9._-]+)$') {
        throw 'Checksum manifest format is invalid.'
    }
    $path = Join-Path $folder $Matches[2]
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Release file is missing: $($Matches[2])"
    }
    $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $Matches[1]) {
        throw "Release checksum mismatch: $($Matches[2])"
    }
}
if ($signature.Status -eq 'Valid') {
    Write-Host "Verified publisher: $($signature.SignerCertificate.Subject)"
} else {
    Write-Host 'Publisher signature: unsigned experimental build'
}
Write-Host 'Every release checksum is valid.'
